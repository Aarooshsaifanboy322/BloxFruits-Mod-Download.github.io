# Modmenu Codes
# Bloxfruits modmenu by AarooshTheModmenuMaker

# Imports
import time

# Python System
PYTHON = [
    'System', 'main.py', 'Printing system', 'Numbers', 'Wait', 'Pygame', '.py', '.py', '.py extension', 'pip install', 'pip3 install', 'Console', 'Save', 'VS code main_source', 'main_source', 'Python.py (main.py)', 'sys', 'Modmenu_codes.exe'
]
MODMENU = [
     'Modmenu_Files'
]
TERMINAL_TYPE = ['macOS']
TESTER = [
     'macOS',
     'Windows 10',
     'Windows 11',
     'Windows 12'
]
RUNNER = [
     'Android',
     'iPhone',
     'Tablet'
]
MODMENU_OPENER = [
     'Android',
     'iPhone',
     'Tablet'
]
MODMENU_FOR = "Roblox.app", "Roblox"

# Loading Modmenu_Files
print("Please wait, Modmenu Files are loading. This may take a few moments...")
time.sleep(14)

# Modmenu
Assets = ['Modmenu[folder]','random[files[folder(Modmenu_Files)]]']
# Config = modmenu[accept];

print("Accepting Files...")
time.sleep(1)
print("Accepted!")
print("Done loading.")

# Modmenu
print("Modmenu by AarooshTheModmenuMaker.")
while True:
    Modmenu_hacks = str(input("Please select the name you want to use.\n1. Noclip\n2. Jump unbelievably high\n3. Auto Play\n4. Auto Click\nJust type the numbers. If you wanna exit, type exit. "))
    if Modmenu_hacks == "1":
        while True:
         print("Noclip on. Press F to turn off.")
         Key = str(input(""))
         if Key == "f" or Key == "F":
            print("Off. Press O to turn on")
            Key2 = str(input(""))
    elif Modmenu_hacks == "2":
        while True:
            print("Jump high on. Press F to turn off.")
            Key3 = str(input(""))
            if Key3 == "f" or Key3 == "F":
                print("Off. Press O to turn on")
                Key4 = str(input(""))
    elif Modmenu_hacks == "3":
        while True:
            print("Auto Play on. Press F to turn off.")
            Key5 = str(input(""))
            if Key5 == "f" or Key5 == "F":
                print("Off. Press O to turn on")
                Key6 = str(input(""))
    elif Modmenu_hacks == "exit" or "Exit":
        print("Clearing Codes...")
        time.sleep(13)
        PYTHON.clear()
        print("Terminating Modmenu...")
        time.sleep(16)
        print("Done!")
        time.sleep(0.2)
        quit("You have exited BloxFruits Modmenu.")
    elif Modmenu_hacks == "exit" or Modmenu_hacks == "Exit":
     Modmenu_hacks2 = str(input("Please select the name you want to use.\n1. Noclip\n2. Jump unbelievably high\n3. Auto Play\n4. Auto Click\nJust type the numbers. If you wanna exit, type exit. "))
     if Modmenu_hacks2 == 1:
        while True:
            print("Noclip on. Press F to turn off.")
            Key7 = str(input(""))
            if Key7 == "f" or Key7 == "F":
                print("Off. Press O to turn on")
                Key8 = str(input(""))
     elif Modmenu_hacks2 == 2:
            while True:
                print("Jump high on. Press F to turn off.")
                Key9 = str(input(""))
                if Key9 == "f" or Key9 == "F":
                    print("Off. Press O to turn on")
                    Key10 = str(input(""))
     elif Modmenu_hacks2 == 3:
            while True:
                print("Auto Play on. Press F to turn off.")
                Key11 = str(input(""))
                if Key11 == "f" or Key11 == "F":
                    print("Off. Press O to turn on")
                    Key12 = str(input(""))